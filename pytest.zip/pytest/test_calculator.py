from pytest1.test_1 import Calculator
from datetime import datetime, date
import pytest
class Test_01:
    def setup(self):
        print('\n--------函数开始------',end='')
    
    def teardown(self):#方法后置
        print('\n---------函数结束--------',end='')
    
    def setup_class(self):#类前置
        print('\n---------类开始--------',end='')
    
    def teardown_class(self):#类后置
        print('\n---------类结束--------',end='')
    
    def test_calculate_addition(self):
        cal = Calculator()
        ans = cal.calculate_addition(2.0, 3.0)
        assert ans == 5.0
     
    def test_calculate_multiply(self):
        cal = Calculator()
        ans = cal.calculate_multiply(2.0, 3.0)
        assert ans == 6.0
    
    def test_calculate_substraction(self):
        cal = Calculator()
        ans = cal.calculate_substraction(2.0, 3.0)
        assert ans == -1.0
    
    def test_calculate_divide(self):
        cal = Calculator()
        ans = cal.calculate_divide(6.0, 3.0)
        assert ans == 2.0
    
    def test_calculate_divide2(self):
        with pytest.raises(ValueError):
           cal = Calculator()
           ans = cal.calculate_divide(2.0, 0.0)
        
    def test_calculate_age(self):
        cal = Calculator()
        ans = cal.calculate_age(date(2005, 7, 10))
        assert ans == 17
    
    def test_calculate_age1(self):
        cal = Calculator()
        ans = cal.calculate_age(date(2005, 11, 10))
        assert ans == 18
   
    def test_calculate_age2(self):
        with pytest.raises(ValueError):
           cal = Calculator()
           ans = cal.calculate_age(2024, 7, 7) 
