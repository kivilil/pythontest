from typing import Union, Dict
from pytest1.test_2 import get_source_data, generate_report
from typing import Union, Dict
from pandas import DataFrame
import pytest

def test_get_source_data():
    ans = get_source_data()
    rst = isinstance(ans["metrics_data"], DataFrame )
    assert rst ==True

def test_generate_report1():
    ans = get_source_data()
    rst = generate_report(ans,"str")
    assert rst == False

def test_generate_report2():
    with pytest.raises(AttributeError): 
           rst = generate_report("test",{})
           assert rst == False

def test_generate_report3():
    ans = get_source_data()
    rst = generate_report(ans, {})
    assert rst == True